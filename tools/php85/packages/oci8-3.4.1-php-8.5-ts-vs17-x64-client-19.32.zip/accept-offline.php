<?php
// Module inspection only: no Oracle connection functions are called.
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit(1);
}
error_reporting(E_ALL);
set_error_handler(static function ($level, $message, $file, $line) {
    throw new ErrorException($message, 0, $level, $file, $line);
});
ob_start();
phpinfo(INFO_MODULES);
$moduleInfo = ob_get_clean();
preg_match('/^Oracle Compile-time Instant Client Version => (.+)$/m', $moduleInfo, $compileMatch);
$result = [
    'php' => PHP_VERSION,
    'thread_safe' => (bool) PHP_ZTS,
    'bits' => PHP_INT_SIZE * 8,
    'oci8' => phpversion('oci8'),
    'oracle_compile_time' => trim($compileMatch[1] ?? ''),
    'oracle_runtime' => function_exists('oci_client_version') ? oci_client_version() : null,
    'oci_functions' => array_map('function_exists', ['oci_connect', 'oci_new_cursor', 'oci_parse', 'oci_execute', 'oci_bind_by_name']),
    'database_connections' => 0,
];
$passed = $result['php'] === '8.5.12'
    && $result['thread_safe'] && $result['bits'] === 64
    && $result['oci8'] === '3.4.1'
    && preg_match('/^19\.32(?:\.|$)/', $result['oracle_compile_time']) === 1
    && $result['oracle_runtime'] === '19.32.0.0.0'
    && !in_array(false, $result['oci_functions'], true);
$result['accepted_offline'] = $passed;
echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), PHP_EOL;
exit($passed ? 0 : 1);
