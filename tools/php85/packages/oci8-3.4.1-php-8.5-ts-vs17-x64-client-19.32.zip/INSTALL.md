# Install the GFC OCI8 package on Windows

This package contains a ready `php_oci8_19.dll` built from OCI8 3.4.1 with Oracle Client 19.32. It passed loading checks on **PHP 8.5.12, Thread Safe, VS17, x64** in CLI and Apache. You do not need C++ build tools or Oracle SDK.

For the complete application setup, follow the **INSTALL.md in the GFC project root**. This file covers the OCI8 extension only.

## 1. Install the prerequisites

Install PHP 8.5.12 **TS / VS17 / x64** as described in the project guide. The examples below use `C:\xampp\php8512`.

Download and install [Microsoft Visual C++ Redistributable x64](https://aka.ms/vc14/vc_redist.x64.exe).

Download [Oracle Instant Client Basic 19.32 x64](https://download.oracle.com/otn_software/nt/instantclient/1932000/instantclient-basic-windows.x64-19.32.0.0.0dbru.zip). Use the full **Basic** package. Verify its SHA256 before extracting it:

```powershell
$ErrorActionPreference = 'Stop'
$BasicZip = "$env:USERPROFILE\Downloads\instantclient-basic-windows.x64-19.32.0.0.0dbru.zip"
if ((Get-FileHash -LiteralPath $BasicZip -Algorithm SHA256).Hash -ne 'e95a66eb4e69e2fb28880cbd252e8eab9807b877c4248c0d50a28f7b75cfe878') {
    throw 'Oracle download checksum does not match. Stop here.'
}
# If this client folder already exists, verify it instead of overwriting it.
if (Test-Path -LiteralPath 'C:\oracle\instantclient_19_32') {
    throw 'Oracle Client 19.32 already exists. Check it before continuing.'
}
New-Item -ItemType Directory -Path 'C:\oracle' -Force | Out-Null
Expand-Archive -LiteralPath $BasicZip -DestinationPath 'C:\oracle'
```

You should now have `C:\oracle\instantclient_19_32\oci.dll`. Add `C:\oracle\instantclient_19_32` to **System environment variables > Path**, before other Oracle clients used by this Apache instance. Reopen PowerShell and XAMPP Control Panel after changing PATH. A Windows service must be restarted to receive the new environment.

Do not set `ORACLE_HOME` for Instant Client or copy Oracle DLLs into `System32` or PHP's `ext` directory.

## 2. Copy the PHP extension

Stop Apache. Extract this ZIP into a new folder and open PowerShell **in that extracted folder**. Change `$Xampp` if your installation uses another path.

```powershell
$ErrorActionPreference = 'Stop'
$Xampp = 'C:\xampp'
$Dll = Join-Path (Get-Location) 'php_oci8_19.dll'
$Target = Join-Path $Xampp 'php8512\ext\php_oci8_19.dll'
if ((Get-FileHash -LiteralPath $Dll -Algorithm SHA256).Hash -ne 'F60D475675B08C214820A86CC06FC72CD6C3CB64B38D5C5720F90BC2E5ED1D36') {
    throw 'OCI8 DLL checksum does not match. Stop here.'
}
if (Test-Path -LiteralPath $Target) {
    $Backup = Join-Path $Xampp ('oci8-backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
    New-Item -ItemType Directory -Path $Backup | Out-Null
    Copy-Item -LiteralPath $Target -Destination $Backup
}
Copy-Item -LiteralPath $Dll -Destination $Target
```

In `C:\xampp\php8512\php.ini`, set these values once. Adjust the path if needed:

```ini
extension_dir="C:/xampp/php8512/ext"
extension=php_oci8_19.dll
```

## 3. Check the result

Open a new PowerShell window. From the extracted package folder, run:

```powershell
$Php = 'C:\xampp\php8512\php.exe'
& $Php --ri oci8
if ($LASTEXITCODE -ne 0) { throw 'OCI8 could not be loaded.' }
& $Php .\accept-offline.php
if ($LASTEXITCODE -ne 0) { throw 'The offline OCI8 check failed.' }
```

Expected values:

```text
OCI8 Version => 3.4.1
Oracle Run-time Client Library Version => 19.32.0.0.0
Oracle Compile-time Instant Client Version => 19.32
accepted_offline: true
```

If compile-time shows `23.x`, check which DLL you copied. If runtime shows another client version, check the process PATH and restart the terminal or Apache service. Then start Apache and complete the web-server check in the project's INSTALL.md.

## Package contents and test scope

`BUILD-INFO.json` records the build inputs and toolchain. `ACCEPTANCE-cli.json` and `ACCEPTANCE-apache.json` record the loading checks. `SHA256SUMS.txt` lists the package file hashes; `LICENSE` and `CREDITS` are included from the source.

The package contains the PHP extension only. Oracle Basic is downloaded separately. No VPN or Oracle connection was used for the build or loading checks. Test the real database when the company network is available. Client 19 supports Oracle Database **11.2 and later**; confirm that an "11g" database is 11.2, not 11.1. See the [OCI8 requirements](https://www.php.net/manual/en/oci8.requirements.php).
